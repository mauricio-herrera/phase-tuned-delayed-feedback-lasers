# JOSA B 612251 — consolidated revision package R2, 11 October 2026

## Scientific status

Seven missing analytic revision entry points have been reconstructed (plus a shared analytic library, a validation gate, an ECM merger, a batch script, and raw Mac results). All nine combinations of Supplement Table S8 agree exactly, and Tables S2/S3/S10–S13 agree at their respective reporting precision. The submitted Mac stochastic `results.zip` passed the existing structural QA and matched the pilot as described in `JOSAB_612251_AUDITORIA_RESULTS_2026-10-11.md`.

## Files to use

- `Final_to_upload/`: compiled clean/marked manuscript, clean/marked supplement, response letter PDFs and **five flat native-source ZIPs**.
- `JOSAB_612251_Revision_Reproducibility.zip`: standalone reproducibility package, containing code, the rebuilt analytical CSVs, and Mac raw data.
- `Reproducibility/`: editable scripts, results and tables.
- `REVIEWER_RESPONSE_CROSSCHECK.md`: scientific and editorial crosscheck.
- `PUBLISH_GITHUB_REVISION.sh`: reproducibility branch/PR publishing helper to run locally on macOS after authentication.

## Where publication actions still require your account

1. GitHub: publish/merge the verified revision branch into `mauricio-herrera/phase-tuned-delayed-feedback-lasers` (helper script provided). This has **not** been done by producing these files.
2. Zenodo: create a **new version** of the pre-existing Zenodo archive and upload `JOSAB_612251_Revision_Reproducibility.zip`. Check the DOI shown by Zenodo before editing the manuscript to quote a new identifier.
3. Prism: confirm actual funding sources, author affiliation/ORCID, upload native manuscript, supplement, response, and separate revision reproducibility ZIP, inspect generated proof, and submit.

Do not upload the umbrella workspace ZIP to Prism as a single manuscript file. Upload each item to its appropriate slot/role.
